package com.example.my_tflit_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
